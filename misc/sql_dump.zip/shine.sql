-- phpMyAdmin SQL Dump
-- version 5.0.0-dev
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 25, 2018 at 08:54 PM
-- Server version: 5.7.23-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shine`
--
CREATE DATABASE IF NOT EXISTS `shine` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shine`;

-- --------------------------------------------------------

--
-- Table structure for table `shine_activations`
--

CREATE TABLE `shine_activations` (
  `id` int(11) NOT NULL,
  `app_id` int(11) DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial_number` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dt` datetime DEFAULT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_applications`
--

CREATE TABLE `shine_applications` (
  `id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bundle_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `upgrade_app_id` int(11) NOT NULL,
  `s3key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `s3pkey` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `s3bucket` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `s3path` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `s3url` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dirpath` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sparkle_key` text COLLATE utf8_unicode_ci NOT NULL,
  `sparkle_pkey` text COLLATE utf8_unicode_ci NOT NULL,
  `ap_key` text COLLATE utf8_unicode_ci NOT NULL,
  `ap_pkey` text COLLATE utf8_unicode_ci NOT NULL,
  `from_email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email_subject` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email_body` text COLLATE utf8_unicode_ci NOT NULL,
  `license_filename` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `custom_salt` text COLLATE utf8_unicode_ci NOT NULL,
  `license_type` enum('ap','custom') COLLATE utf8_unicode_ci NOT NULL,
  `return_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fs_security_key` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `i_use_this_key` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `tweet_terms` text COLLATE utf8_unicode_ci NOT NULL,
  `hidden` tinyint(4) NOT NULL,
  `engine_class_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_downloads`
--

CREATE TABLE `shine_downloads` (
  `id` int(11) NOT NULL,
  `dt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `referer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `referer_is_local` tinyint(4) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `page_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `search_terms` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `img_search` tinyint(4) NOT NULL DEFAULT '0',
  `browser_family` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `browser_version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `os` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `os_version` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `exec_time` float NOT NULL DEFAULT '0',
  `num_queries` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_feedback`
--

CREATE TABLE `shine_feedback` (
  `id` int(11) NOT NULL,
  `appname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `appversion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `systemversion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `reply` tinyint(4) NOT NULL,
  `type` enum('support','feature','bug') COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `importance` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `critical` tinyint(4) NOT NULL,
  `dt` datetime NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `new` tinyint(4) NOT NULL,
  `starred` tinyint(4) NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `reguser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `regmail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_options`
--

CREATE TABLE `shine_options` (
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_orders`
--

CREATE TABLE `shine_orders` (
  `id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL,
  `dt` datetime NOT NULL,
  `txn_type` varchar(25) CHARACTER SET latin1 NOT NULL,
  `first_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `residence_country` varchar(25) CHARACTER SET latin1 NOT NULL,
  `item_name` varchar(25) CHARACTER SET latin1 NOT NULL,
  `payment_gross` float NOT NULL,
  `mc_currency` varchar(25) CHARACTER SET latin1 NOT NULL,
  `business` varchar(128) CHARACTER SET latin1 NOT NULL,
  `payment_type` varchar(25) CHARACTER SET latin1 NOT NULL,
  `verify_sign` varchar(128) CHARACTER SET latin1 NOT NULL,
  `payer_status` varchar(25) CHARACTER SET latin1 NOT NULL,
  `tax` float NOT NULL,
  `payer_email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `txn_id` varchar(128) CHARACTER SET latin1 NOT NULL,
  `quantity` int(11) NOT NULL,
  `receiver_email` varchar(128) CHARACTER SET latin1 NOT NULL,
  `payer_id` varchar(128) CHARACTER SET latin1 NOT NULL,
  `receiver_id` varchar(128) CHARACTER SET latin1 NOT NULL,
  `item_number` varchar(25) CHARACTER SET latin1 NOT NULL,
  `payment_status` varchar(25) CHARACTER SET latin1 NOT NULL,
  `payment_fee` float NOT NULL,
  `mc_fee` float NOT NULL,
  `shipping` float NOT NULL,
  `mc_gross` float NOT NULL,
  `custom` varchar(255) CHARACTER SET latin1 NOT NULL,
  `license` text CHARACTER SET latin1 NOT NULL,
  `type` enum('PayPal','Manual','Student','MUPromo','FastSpring') CHARACTER SET latin1 NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `hash` varchar(5) CHARACTER SET latin1 NOT NULL,
  `claimed` tinyint(4) NOT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_sessions`
--

CREATE TABLE `shine_sessions` (
  `id` int(255) NOT NULL,
  `data` text COLLATE utf8_unicode_ci NOT NULL,
  `updated_on` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_sparkle_data`
--

CREATE TABLE `shine_sparkle_data` (
  `sparkle_id` int(11) NOT NULL,
  `key` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `data` varchar(128) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_sparkle_reports`
--

CREATE TABLE `shine_sparkle_reports` (
  `id` int(11) NOT NULL,
  `dt` datetime NOT NULL,
  `ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_tweets`
--

CREATE TABLE `shine_tweets` (
  `id` int(11) NOT NULL,
  `tweet_id` bigint(20) NOT NULL,
  `username` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `app_id` int(11) NOT NULL,
  `dt` datetime NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `profile_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new` tinyint(4) NOT NULL,
  `replied_to` tinyint(4) NOT NULL,
  `reply_date` datetime NOT NULL,
  `deleted` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_users`
--

CREATE TABLE `shine_users` (
  `id` int(11) NOT NULL,
  `username` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(65) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `level` enum('user','admin') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `email` varchar(65) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(128) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shine_versions`
--

CREATE TABLE `shine_versions` (
  `id` int(11) NOT NULL,
  `app_id` int(11) NOT NULL DEFAULT '0',
  `human_version` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `version_number` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_notes` text COLLATE utf8_unicode_ci NOT NULL,
  `filesize` bigint(20) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `updates` int(11) NOT NULL,
  `signature` varchar(65) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shine_activations`
--
ALTER TABLE `shine_activations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_applications`
--
ALTER TABLE `shine_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_downloads`
--
ALTER TABLE `shine_downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_feedback`
--
ALTER TABLE `shine_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_options`
--
ALTER TABLE `shine_options`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `shine_orders`
--
ALTER TABLE `shine_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_sessions`
--
ALTER TABLE `shine_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_sparkle_data`
--
ALTER TABLE `shine_sparkle_data`
  ADD KEY `sparkle_id` (`sparkle_id`);

--
-- Indexes for table `shine_sparkle_reports`
--
ALTER TABLE `shine_sparkle_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shine_tweets`
--
ALTER TABLE `shine_tweets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`tweet_id`,`app_id`);

--
-- Indexes for table `shine_users`
--
ALTER TABLE `shine_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `shine_versions`
--
ALTER TABLE `shine_versions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `shine_activations`
--
ALTER TABLE `shine_activations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_applications`
--
ALTER TABLE `shine_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_downloads`
--
ALTER TABLE `shine_downloads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_feedback`
--
ALTER TABLE `shine_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_orders`
--
ALTER TABLE `shine_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_sessions`
--
ALTER TABLE `shine_sessions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_sparkle_reports`
--
ALTER TABLE `shine_sparkle_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_tweets`
--
ALTER TABLE `shine_tweets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_users`
--
ALTER TABLE `shine_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shine_versions`
--
ALTER TABLE `shine_versions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
