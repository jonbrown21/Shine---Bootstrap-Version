/*

File: Dazzle.js
Version: 1.0

Description:
	Check for Updates class for Dashboard Widgets. See "http://www.quintusquill.com/code/dazzle/" for more information.
	Inspired by the "Sparkle" framework ("http://sparkle.andymatuschak.org/").

Documentation:
	See main page ("http://www.quintusquill.com/code/dazzle/") for information on how to include Dazzle in your widget.

	See Dazzle Guide ("http://www.quintusquill.com/code/dazzle/guide/") for information on how Dazzle works and how you can use it in your widget.
	See Dazzle Reference ("http://www.quintusquill.com/code/dazzle/reference/") for a complete reference of all Dazzle's options and methods.
	

Copyright (c) 2008 Steve Harrison.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

function Dazzle()
{
	if (arguments.length > 0) {
		var options = arguments[0];
	}
	else {
		var options = [];
	}
	
	// The version of the user's operating system
	this.currentSystemVersion;
	
	// The URL of the appcast
	this.appcastURL;
	
	// Information about the widget (independent of its version)
	this.widgetName;
	this.widgetDisplayName;
	
	// Information about the current version of the widget
	this.currentVersion = {
		version: null,
		displayVersion: null
	};
	
	// Information about the latest version of the widget available
	this.latestVersion = {
		version: null,
		displayVersion: null,
		url: null,
		releaseNotesURL: null
	};
	
	// Whether or not the current version of the widget is the latest version available
	this.isUpToDate = true;
	
	// The last time Dazzle checked for updates (automatic or not)
	this.lastChecked;
	
	// The next automatic check for updates
	this.nextCheck;
	

	// References to some of the HTML elements in the alert box
	this.alertBoxHTML = {
		container: null,
		alertText: null,
		releaseNotesLink: null
	};
	
	// Alert box "Download" button (Apple Glass Button object)
	this.downloadButton;
	// Alert box "Later" button (Apple Glass Button object)
	this.laterButton;


	// Specifies the interval between automatic checks for updates
	this.checkInterval = 1000 * 60 * 60;
	
	// Specifies whether Dazzle should automatically check for updates
	this.shouldAutoCheck = true;
	
	// Specifies whether Dazzle should display the alert box when it finds a new update is available
	this.shouldDisplayAlertBox = true;
	
	// Specifies whether Dazzle should open the URL of the update in Safari when the user clicks the "Download" button in the alert box
	this.shouldOpenUpdateInSafari = true;
	
	// Specifies the namespace of the custom elements/attributes that can be used in Dazzle appcasts
	this.namespaceURL = "http://www.quintusquill.com/specs/dazzle-xmlns/";
	

	this.Request = "";
	this.shouldSetTimeout = true;
	this.insertValuesIntoAlertBox_RetryCounter = 0;
	this.setShouldDisplayReleaseNotesLink_RetryCounter = 0;
	this.checkForUpdates_RetryCounter = 0;
	

	if (window.widget)
	{
		// Get the user's OS version
		widget.system("/usr/bin/sw_vers", function() {
			thisClass.currentSystemVersion = this.outputString.match(/ProductVersion:\t.*/)[0].replace("ProductVersion:	", "");
		});
	}
	

	/* Process Options */


	function getInfoKey(key, onComplete)
	{
		if (window.widget)
		{
			var errorFunction = arguments[2];

			// Use a Terminal command to read the widget's Info.plist file
			widget.system("/usr/bin/defaults read '" + window.location.pathname.replace(/[^/]*$/, "Info'") + " " + key, function()
			{
				if (this.status == 0)
				{
					// If the command was successful, process the result and pass it to the onComplete handler.
					var keyValue = this.outputString.replace("\n", "");
					onComplete(keyValue);
				}
				else
				{
					// If the command was not successful, call the onError handler if supplied as a third argument
					if (errorFunction) {
						errorFunction();
					}
				}
			});
		}
	}
	
	// Save the pointer to the Dazzle class (for use in functions)
	var thisClass = this;


	/* ----- Data Options ----- */
	

	/* Appcast URL */
	
	if (options.appcastURL) {
		this.appcastURL = options.appcastURL;
	}
	else {
		// Get the Appcast URL from the Info.plist file
		getInfoKey("DUAppcastURL",
		function(appcastURL)
		{
			thisClass.appcastURL = appcastURL;
		},
		function()
		{
			alert("Dazzle Error: No appcast URL specified. You must specify an appcast URL as either an 'appcastURL' option when you initialise the Dazzle object or a 'DUAppcastURL' key in your Info.plist file.");
		});
	}
	
	/* Display Version */
	
	var checkForDisplayVersion = function()
	{
		if (!options.displayVersion)
		{
			// Get the current widget display version from the Info.plist (if specified)
			getInfoKey("CFBundleShortVersionString",
			function(displayVersion)
			{
				thisClass.currentVersion.displayVersion = displayVersion;
			},
			function()
			{
				// If not specified, set it to "CFBundleVersion"
				thisClass.currentVersion.displayVersion = thisClass.currentVersion.version;
			});
		}
	};
	
	if (options.bundleDisplayVersion) {
		this.currentVersion.displayVersion = options.bundleDisplayVersion;
	}
			
	if (options.bundleVersion) {
		this.currentVersion.version = options.bundleVersion;
		checkForDisplayVersion();
	}
	else {
		// Get the current widget version
		getInfoKey("CFBundleVersion", function(version)
		{
			thisClass.currentVersion.version = version;
			checkForDisplayVersion();
		});
	}
	
	/* Widget Name/Display Name */
	
	var checkForDisplayName = function()
	{
		// If we haven't been supplied the widget display name, we check for it in the Info.plist
		if (!options.widgetDisplayName)
		{
			// Get the bundle display name from the Info.plist (if specified)
			getInfoKey("CFBundleDisplayName",
			function(widgetDisplayName)
			{
				thisClass.widgetDisplayName = widgetDisplayName;
			},
			function()
			{
				// If not specified, set it to "CFBundleName"
				thisClass.widgetDisplayName = thisClass.widgetName;
			});
		}
	};

	if (options.widgetDisplayName) {
		this.widgetDisplayName = options.widgetDisplayName;
	}
			
	if (options.widgetName) {
		this.widgetName = options.widgetName;
		checkForDisplayName();
	}
	else {
		// Get the bundle name from the Info.plist
		getInfoKey("CFBundleName", function(widgetName) {
			thisClass.widgetName = widgetName;
			checkForDisplayName();
		});
	}
	
	
	/* ----- Preference Options ----- */
	
	
	function isOption(option)
	{
		if (option != undefined && option != null) {
			return true;
		}
		else {
			return false;
		}
	}

	// Note: We only use the "isOption" function for options that will have a value of true/false

	if (options.checkInterval) {
		this.setCheckInterval(options.checkInterval);
	}
			
	if (isOption(options.shouldAutoCheck)) {
		this.setShouldAutoCheck(options.shouldAutoCheck);
	}
	
	if (isOption(options.shouldDisplayAlertBox)) {
		this.setShouldDisplayAlertBox(options.shouldDisplayAlertBox);
	}
	
	if (isOption(options.shouldOpenUpdateInSafari)) {
		this.shouldOpenUpdateInSafari = options.shouldOpenUpdateInSafari;
	}

	if (options.useSparkleNamespace) {
		this.namespaceURL = "http://www.andymatuschak.org/xml-namespaces/sparkle";
	}
				
	this.createHTML();
	
	if (options.shouldDisplayReleaseNotesLink == true) {
		this.setShouldDisplayReleaseNotesLink(true);
	}

	if (options.initWithCheck != false && options.shouldAutoCheck != false) {
		// Finish initialization by checking for updates.
		this.update();
	}
}


/* ============== Dazzle HTML Display Code ============== */


Dazzle.prototype.createHTML = function()
{

/* Create the HTML */

	var alertBox = document.createElement("div");
	alertBox.id = "dazzle-alertBox";
	
		var alertBoxBG = document.createElement("div");
		alertBoxBG.id = "dazzle-alertBox-background";
		/*	alertBoxBG.innerHTML inserted further down	*/
		alertBox.appendChild(alertBoxBG);

		var alertText = document.createElement("p");
		alertText.id = "dazzle-alertBox-alertText";
		alertBox.appendChild(alertText);
	
		var releaseNotesText = document.createElement("p");
		releaseNotesText.id = "dazzle-alertBox-releaseNotesText";
		alertBox.appendChild(releaseNotesText);
		
			var releaseNotesLink = document.createElement("a");
			releaseNotesLink.innerHTML = "Open Release Notes in Browser";
			releaseNotesText.appendChild(releaseNotesLink);
			
		var buttons = document.createElement("div");
		buttons.id = "dazzle-alertBox-buttons";
		alertBox.appendChild(buttons);
		
			var laterButton = document.createElement("div");
			laterButton.id = "dazzle-alertBox-laterButton";
			buttons.appendChild(laterButton);

			var downloadButton = document.createElement("div");
			downloadButton.id = "dazzle-alertBox-downloadButton";
			buttons.appendChild(downloadButton);
			
	// Save the elements to be accessed later
	var alertBoxHTML = this.alertBoxHTML;
	alertBoxHTML.container = alertBox;
	alertBoxHTML.alertText = alertText;
	alertBoxHTML.releaseNotesLink = releaseNotesLink;

/* Set up the buttons */

	// Save the pointer to the Dazzle class
	var thisClass = this;

	// "Download" Button
	this.downloadButton = new AppleGlassButton(downloadButton, "Download", function() {
		thisClass.downloadUpdate();
		thisClass.hideAlertBox();
	});

	// "Later" Button
	this.laterButton = new AppleGlassButton(laterButton, "Later", function() {
		thisClass.hideAlertBox();
	});

/* Alert Box Background */
	
	alertBoxBG.innerHTML = '<div id="dazzle-alertBox-topLeft"></div><div id="dazzle-alertBox-topCentre"></div><div id="dazzle-alertBox-topRight"></div><div id="dazzle-alertBox-middleLeft"></div><div id="dazzle-alertBox-middleCentre"></div><div id="dazzle-alertBox-middleRight"></div><div id="dazzle-alertBox-bottomLeft"></div><div id="dazzle-alertBox-bottomCentre"></div><div id="dazzle-alertBox-bottomRight"></div>';
		
/* Insert the HTML into the Document */		

	var front = document.getElementById("front");
	
	if (front) {
		front.appendChild(alertBox);
	}
	else {
		var body = document.getElementsByTagName("body")[0];
		body.appendChild(alertBox);
	}
}

Dazzle.prototype.insertValuesIntoAlertBox = function(onComplete)
{
	var thisClass = this;
	
	var widgetName = this.widgetName;
	var latestVersionString = this.latestVersion.displayVersion;
	var currentVersionString = this.currentVersion.displayVersion;

	if (widgetName && latestVersionString && currentVersionString)
	{
		// Reset the retry counter
		this.insertValuesIntoAlertBox_RetryCounter = 0;
		
		var alertBoxHTML = this.alertBoxHTML;

		// Update the Alert Text
		alertBoxHTML.alertText.innerHTML = widgetName + " " + latestVersionString + " is available (you have " + currentVersionString + ").  Would you like to download the new version?";
		
		// Update the Release Notes URL
		alertBoxHTML.releaseNotesLink.onclick = function () { widget.openURL(thisClass.latestVersion.releaseNotesURL); };
	
		onComplete();
	}
	else
	{
		dazzle_retry(function() { thisClass.insertValuesIntoAlertBox(onComplete); }, thisClass.insertValuesIntoAlertBox_RetryCounter);
	}
}

Dazzle.prototype.displayAlertBox = function()
{
	var thisClass = this;
	
	this.insertValuesIntoAlertBox(function() {
		
		// Stop Dazzle from automatically checking for updates (there's no need to do anything until the user has dismissed the alert box)
		thisClass.setShouldAutoCheck(false);

		var alertBox = thisClass.alertBoxHTML.container;
		
		alertBox.style.display = "block";

		if (alertBox.style.opacity == 0)
		{
			// Fade in the alert box
			var fadeHandler = function(a, c, s, f) { alertBox.style.opacity = c; };
			new AppleAnimator(280, 13, 0.0, 1.0, fadeHandler).start();
		}

	});
}

Dazzle.prototype.hideAlertBox = function()
{
	// Schedule the next check for updates
	this.setNextCheck();
	
	// Tell Dazzle to automatically check for updates again
	this.setShouldAutoCheck(true);

	var alertBox = this.alertBoxHTML.container;

	// Fade out the alert box
	var fadeHandler = function(a, c, s, f) { alertBox.style.opacity = c; };
	var animator = new AppleAnimator(280, 13, 1.0, 0.0, fadeHandler);
	animator.oncomplete = function() { alertBox.style.display = "none"; };
	animator.start();
}

Dazzle.prototype.downloadUpdate = function()
{
	if (window.widget)
	{
		var thisClass = this;
		
		if (this.shouldOpenUpdateInSafari)
		{
			// Open the URL in Safari (because Safari unzips and installs downloaded widgets)
			widget.system('open -b "com.apple.Safari" "' + thisClass.latestVersion.url + '"', function()
			{
				if (this.status == 0) {
					// If we succeeded, hide the Dashboard
					widget.openURL("");
				}
				else {
					// If we didn't succeed, open the URL in the user's default browser
					widget.openURL(thisClass.latestVersion.url);
				}
			});
		}
		else
		{
			widget.openURL(thisClass.latestVersion.url);
		}
	}
}


/* ============== Dazzle User Code ============== */


Dazzle.prototype.setCheckInterval = function(interval)
{
	var type = typeof(interval);
	
	if (type == "number")
	{
		this.checkInterval = interval;
	}
	else if (type == "string")
	{
		switch(interval)
		{
			case "never":
				this.checkInterval = 0;
				break;
			case "hourly":
				this.checkInterval = 1000 * 60 * 60;
				break;
			case "daily":
				this.checkInterval = 1000 * 60 * 60 * 24;
				break;
			case "weekly":
				this.checkInterval = 1000 * 60 * 60 * 24 * 7;
				break;
			// case "monthly":
			//	this.checkInterval = 1000 * 60 * 60 * 24 * 7 * 31;	<-- Not all months have 31 days
			default:
				alert("Dazzle Error: Dazzle.setCheckInterval() method called with incorrect argument (Argument Type: String. Error: String did not match available options: 'never', 'hourly', 'daily', or 'weekly').");
		}
	}
}

Dazzle.prototype.setShouldAutoCheck = function(shouldAutoCheck)
{
	// Enable/disable automatic checks for updates
	this.shouldAutoCheck = shouldAutoCheck;
	
	if (shouldAutoCheck == true) {
		this.update();
	}
}

Dazzle.prototype.setShouldDisplayAlertBox = function(shouldDisplayAlertBox)
{
	this.shouldDisplayAlertBox = shouldDisplayAlertBox;
}

Dazzle.prototype.setShouldDisplayReleaseNotesLink = function(shouldDisplayReleaseNotesLink) {
	if (shouldDisplayReleaseNotesLink) {
	
		// Show the release notes text

		this.alertBoxHTML.releaseNotesLink.parentNode.style.display = "block";
		
		// Change the height of the alert box
		
		var currentHeight = document.defaultView.getComputedStyle(this.alertBoxHTML.container, null).getPropertyValue("height");
		
		var retryCounter = this.setShouldDisplayReleaseNotesLink_RetryCounter;
		var thisClass = this;
		
		if (currentHeight.search("px") == -1) {
			dazzle_retry(function() { thisClass.setShouldDisplayReleaseNotesLink(shouldDisplayReleaseNotesLink); }, retryCounter);
		}
		else {
			retryCounter = 0;

			var newHeight = parseInt(currentHeight) + 25 + "px";
			this.alertBoxHTML.container.style.height = newHeight;
		}
	}
}

Dazzle.prototype.abortRequest = function()
{
	// I can't think when "abortRequest" would need to be used, but you never know...

	// Stop the XMLHttpRequest if it is currently running
	var Request = this.Request;
	if (Request != "") {
		Request.abort();
	}
}

Dazzle.prototype.onShow = function()
{
	this.shouldSetTimeout = true;
	this.update();
}

Dazzle.prototype.onHide = function()
{
	this.shouldSetTimeout = false;
	clearTimeout(this.checkTimeout);
}


/* ============== Dazzle Core ============== */



Dazzle.prototype.setNextCheck = function()
{
	if (!this.nextCheck) {
		this.nextCheck = new Date();
	}

	var now = new Date();
		
	var timeForNextCheck = now.getTime() + this.checkInterval;
	this.nextCheck.setTime(timeForNextCheck);

	this.setCheckTimeout();
}

Dazzle.prototype.setCheckTimeout = function()
{
	// 0 means never check, and we don't want to set a timeout if "this.shouldSetTimeout" is false
	if (this.checkInterval == 0 || this.shouldSetTimeout == false) {
		return;
	}

	// Number of milliseconds until next check = Next Check (in milliseconds) - Now (in milliseconds)
	var timeUntilNextCheck = this.nextCheck.getTime() - new Date().getTime();

	// Save a pointer to the Dazzle class
	var thisClass = this;

	// Clear the current timeout (if there is one), and then start the timeout
	clearTimeout(this.checkTimeout);
	this.checkTimeout = setTimeout(function() { thisClass.update() }, timeUntilNextCheck);
}

Dazzle.prototype.update = function()
{
	// 0 means never check
	if (this.checkInterval == 0) {
		return;
	}

	// Create Options
	if (arguments.length > 0) {
		var options = arguments[0];
	}
	else {
		var options = [];
	}
	
	var now = new Date();

	if (!this.nextCheck) {
		this.nextCheck = now;
	}
	
	if (this.shouldAutoCheck && this.nextCheck && this.appcastURL && this.currentVersion)
	{
		if (this.nextCheck <= now)
		{
			var thisClass = this;
			
			if (options.onComplete) {
				var current_onComplete = options.onComplete;
			}
			
			options.onComplete = function(status) {
	
				if (status.statusCode < 2) {
					// If statusCode is less than 2, then update wasn't successful
					thisClass.lastChecked = now;
					thisClass.setNextCheck();
				}
				
				if (current_onComplete) {
					current_onComplete();
				}
			};

			this.checkForUpdates(options);
		}
		else
		{
			this.setCheckTimeout();
		}
	}
}

Dazzle.prototype.checkForUpdates = function()
{
	// Create Options
	if (arguments.length > 0) {
		var options = arguments[0];
	}
	else {
		var options = [];
	}
	
	if (options.onStart)
		options.onStart();
	
	// Clear the timeout - we're checking for updates now
	clearTimeout(this.checkTimeout);

	// Save the pointer to the Dazzle class
	var thisClass = this;

	// If we haven't finished retrieving the needed keys (Version Number and Appcast URL) from the Info.plist file,
	// or we haven't finished retrieving the current system version, we delay the "checkForUpdates" method
	// until the data has been retrieved (in which case, the relevant instance variables will contain values).

	// If the instance variables still are undefined after many tries, then we report an error,
	// because it shouldn't take that long to retrieve the data.

	if (!this.appcastURL || !this.currentVersion.version || !this.currentSystemVersion)
	{
		dazzle_retry(function() { thisClass.checkForUpdates(options) }, thisClass.checkForUpdates_RetryCounter, function() {
			var errorText = "One or more of the following instance variables is undefined: Appcast URL, Current Version, Current System Version.";
			alert("Dazzle Error: " + errorText);

			if (options.onComplete)
				options.onComplete({ statusCode: -1, statusText: errorText });
		});
	}
	else
	{
		// Reset the retry counter
		this.checkForUpdates_RetryCounter = 0;
		
		// Get the Appcast
		this.getAppcast(options);
	}
}

Dazzle.prototype.getAppcast = function(options)
{
	// Save the pointer to the Dazzle class
	var thisClass = this;
	
	// We add the random number to the end of the URL to get around caching
	var url = this.appcastURL + "?" + Math.random();

	var Request = this.Request;

	Request = new XMLHttpRequest();
	Request.onreadystatechange = function()
	{
		if (Request.readyState == 4)
		{
			if (Request.status == 200)
			{
				// Parse the AppCast
				thisClass.parseAppcast(Request, options);
				
				// Reset the "this.Request" instance variable
				this.Request = "";
			}
			else
			{
				var errorText = "Couldn't retrieve the appcast XML data from: " + url + ". Request Status Code: " + Request.status;
				alert("Dazzle Error: " + errorText);

				if (options.onComplete)
					options.onComplete({ statusCode: 0, statusText: errorText });
			}
		}
	}
	Request.open("GET", url, true);
	Request.send("");
}

Dazzle.prototype.parseAppcast = function(Request, options)
{
	/* Parse the RSS Feed */

	var response = Request.responseXML;
	
	var items = response.getElementsByTagName("item");
	
	for (var i = 0; i < items.length; i++)
	{
		var item = items[i];

		var description = item.getElementsByTagName("description")[0];
		var enclosure = item.getElementsByTagName("enclosure")[0];

		if (enclosure)
		{
			// Minimum System Version
	
			var minimumSystemVersion = enclosure.getAttributeNS(this.namespaceURL, "minimumSystemVersion");

			if (minimumSystemVersion)
			{
				// If the minimumSystem version is greater than the current system version,
				// we continue processing other items in the appcast

				if (minimumSystemVersion > this.currentSystemVersion) {
					continue;
				}
			}
			
			// Get the Version Number
			
			var versionURL = enclosure.getAttribute("url");
			var version = enclosure.getAttributeNS(this.namespaceURL, "version");
			
			// If a version number isn't provided, then we extract version number from the URL
			if (!version) {
				var version = this.extractVersionFromURL(versionURL);
				// If this didn't work, then we continue processing other items in appcast
				if (!version) {
					continue;
				}
			}
			
			// Update our latestVersion instance variable object

			var latestVersion = this.latestVersion;
			latestVersion.version = version;
			latestVersion.url = versionURL;
			
			var shortVersionString = enclosure.getAttributeNS(this.namespaceURL, "shortVersionString");
			var releaseNotesLink = item.getElementsByTagNameNS(this.namespaceURL, "releaseNotesLink")[0];
			
			if (shortVersionString) {
				latestVersion.displayVersion = shortVersionString;
			}
			else {
				latestVersion.displayVersion = version;
			}

			if (releaseNotesLink) {
				latestVersion.releaseNotesURL = releaseNotesLink.firstChild.nodeValue;
			}

			// Check whether latest version is newer than current version

			if (version > this.currentVersion.version)
			{
				this.isUpToDate = false;

				// Display the Alert Box
				if (options.shouldDisplayAlertBox) {
					this.displayAlertBox();
				}
				else if (this.shouldDisplayAlertBox && options.shouldDisplayAlertBox != false) {
					this.displayAlertBox();
				}
				
				var status = { statusCode: 3, statusText: "There is a newer version of this widget available." };
			}
			else
			{
				this.isUpToDate = true;
				var status = { statusCode: 2, statusText: "This is the latest version of the widget." };
			}
			
			// Save the current date to our "lastChecked" instance variable
			this.lastChecked = new Date();
			
			// Shedule the next check and start the timeout
			this.setNextCheck();
			
			// Log the result to the Console
			alert("Dazzle - Is Up to Date: " + this.isUpToDate);
			
            // Values you provide
            var preferenceKey = "uptodate";		// replace with the key for a preference
            var preferenceValue = this.isUpToDate;	// replace with a preference to save

            // Preference code
            widget.setPreferenceForKey(preferenceValue, widget.identifier + "-" + preferenceKey);
            
			// We're done
			if (options.onComplete)
				options.onComplete(status);
				
			// No need to process other appcast items - we've succeeded in finding our information
			return;
		}
	}
	
	var errorText = "Couldn't find any related items in Appcast.";
	
	alert("Dazzle Error: " + errorText);
	
	if (options.onComplete)
		options.onComplete({ statusCode: 1, statusText: errorText });
}

Dazzle.prototype.extractVersionFromURL = function(url)
{
	// Example of value of "url": "http://www.quintusquill.com/software/comics/Comics_1.2.wdgt.zip"
	
	// Example: "Comics_1.2.wdgt.zip"
	var archiveName = url.substring(url.lastIndexOf("/") + 1);
	
	// Check whether the archive is the format "WidgetName_VersionNumber"
	if (archiveName.match(/.*_\d*.*./))
	{
		// Check whether the archive extension is ".wdgt.zip" or ".zip" (must be one of these)
		if (archiveName.search(".wdgt.zip") != -1) {
			var extension = ".wdgt.zip";
		}
		else {
			var extension = ".zip";
		}

		// Example: "1.2"
		var version = archiveName.substring(archiveName.lastIndexOf("_") + 1, archiveName.lastIndexOf(extension));
		return version;
	}
}

function dazzle_retry(retryFunction, retryCounter)
{
	// We call the retryFunction every 10 milliseconds for 20 times.
	// If we get called again after 20 tries, we report an error.
	
	if (retryCounter < 20)
	{
		retryCounter++;
		setTimeout(retryFunction, 10);
	}
	else
	{
		var errorFunction = arguments[2];
		if (errorFunction)
			errorFunction();
	}
}